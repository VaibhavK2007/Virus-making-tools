﻿Public Class Form1

    Private Sub CheckBox8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox8.CheckedChanged

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        MsgBox("Este programa a sido creado solamente para crear virus, Virus Mercurio que es como se llama el programa es muy potente ya como bien lo deseais crear el virus.Yo el creador de este programa ruego que le den buen uso y para ello antes de crear un virus desastiven buestro antivirus ya que no podria llegar a funcionar y el antivirus lo eliminara, no abran el virus que creais vuestro equipo podría estar en peligro y podria causar daños a vuestro sistema operativo.")
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        MsgBox("Cristofer Banquetero Muñoz De La Nava.  Codigo.04875379.34888900.04793208.17494063.H.V.K-9750=7453?8473***jir.url***8376357634?gdurjd***")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        MsgBox("error! intentelo mas tarde")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MsgBox("Cierre el Programa para terminar")
    End Sub

    Private Sub CheckBox14_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox14.CheckedChanged

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
